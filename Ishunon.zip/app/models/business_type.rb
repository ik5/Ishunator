class BusinessType < ActiveRecord::Base
end
