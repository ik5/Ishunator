# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ishunon::Application.config.secret_token = '6ec6c6610f5c3b5514194dd6bf60673b3595b04f315fa995b11a836374207c227145f22de922bbcd17e75a9cf7fd34ec6f3447978e6ce3a9b7e4943aa21c30ae'
