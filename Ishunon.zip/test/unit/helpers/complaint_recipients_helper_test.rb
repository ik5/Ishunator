require 'test_helper'

class ComplaintRecipientsHelperTest < ActionView::TestCase
end
